package app.erp.com.erp_app.vo;

/**
 * Created by hsra on 2019-06-21.
 */

public class Bus_infoItemVo {

    private String bus_unit_name;
    private String bus_work_man ;
    private String bus_unit_barcode ;
    private String bus_work_date ;

    public String getBus_unit_name() {
        return bus_unit_name;
    }

    public void setBus_unit_name(String bus_unit_name) {
        this.bus_unit_name = bus_unit_name;
    }

    public String getBus_work_man() {
        return bus_work_man;
    }

    public void setBus_work_man(String bus_work_man) {
        this.bus_work_man = bus_work_man;
    }

    public String getBus_unit_barcode() {
        return bus_unit_barcode;
    }

    public void setBus_unit_barcode(String bus_unit_barcode) {
        this.bus_unit_barcode = bus_unit_barcode;
    }

    public String getBus_work_date() {
        return bus_work_date;
    }

    public void setBus_work_date(String bus_work_date) {
        this.bus_work_date = bus_work_date;
    }
}
