package app.erp.com.erp_app.vo;

/**
 * Created by hsra on 2019-06-21.
 */

public class Reserve_Work_Vo {

    private String last_update;
    private String location_code;
    private String office_group;
    private String garage_name;
    private String put_unit;

    private String unit_code;
    private String unit_name;
    private String unit_cnt;

    private String eb_serial;
    private String unit_bar_code;

    public String getLast_update() {
        return last_update;
    }

    public void setLast_update(String last_update) {
        this.last_update = last_update;
    }

    public String getLocation_code() {
        return location_code;
    }

    public void setLocation_code(String location_code) {
        this.location_code = location_code;
    }

    public String getOffice_group() {
        return office_group;
    }

    public void setOffice_group(String office_group) {
        this.office_group = office_group;
    }

    public String getGarage_name() {
        return garage_name;
    }

    public void setGarage_name(String garage_name) {
        this.garage_name = garage_name;
    }

    public String getPut_unit() {
        return put_unit;
    }

    public void setPut_unit(String put_unit) {
        this.put_unit = put_unit;
    }

    public String getUnit_code() {
        return unit_code;
    }

    public void setUnit_code(String unit_code) {
        this.unit_code = unit_code;
    }

    public String getUnit_name() {
        return unit_name;
    }

    public void setUnit_name(String unit_name) {
        this.unit_name = unit_name;
    }

    public String getUnit_cnt() {
        return unit_cnt;
    }

    public void setUnit_cnt(String unit_cnt) {
        this.unit_cnt = unit_cnt;
    }

    public String getEb_serial() {
        return eb_serial;
    }

    public void setEb_serial(String eb_serial) {
        this.eb_serial = eb_serial;
    }

    public String getUnit_bar_code() {
        return unit_bar_code;
    }

    public void setUnit_bar_code(String unit_bar_code) {
        this.unit_bar_code = unit_bar_code;
    }
}
