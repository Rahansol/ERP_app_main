package app.erp.com.erp_app.vo;

public class Prj_Item_VO {

    public Prj_Item_VO() {
    }

    private String rn;
    private String route_num;

    private String item_1;
    private String item_2;
    private String item_3;
    private String item_4;
    private String item_5;
    private String item_6;
    private String item_7;
    private String item_8;
    private String item_9;
    private String item_10;
    private String item_11;
    private String item_12;
    private String item_13;
    private String item_14;
    private String item_15;
    private String item_16;
    private String item_17;
    private String item_18;
    private String item_19;
    private String item_20;
    private String item_21;
    private String item_22;
    private String item_23;
    private String item_24;
    private String item_25;
    private String item_26;
    private String item_27;
    private String item_28;
    private String item_29;
    private String item_30;
    private String item_31;
    private String item_32;
    private String item_33;
    private String item_34;
    private String item_35;
    private String item_36;
    private String item_37;
    private String item_38;
    private String item_39;
    private String item_40;
    private String item_41;
    private String item_42;
    private String item_43;
    private String item_44;
    private String item_45;
    private String item_46;
    private String item_47;
    private String item_48;
    private String item_49;
    private String item_50;
    private String item_51;
    private String item_52;
    private String item_53;
    private String item_54;
    private String item_55;
    private String item_56;
    private String item_57;
    private String item_58;
    private String item_59;
    private String item_60;
    private String item_61;
    private String item_62;
    private String item_63;
    private String item_64;
    private String item_65;
    private String item_66;
    private String item_67;
    private String item_68;
    private String item_69;
    private String item_70;
    private String item_71;
    private String item_72;
    private String item_73;
    private String item_74;
    private String item_75;
    private String item_76;
    private String item_77;
    private String item_78;
    private String item_79;
    private String item_80;
    private String item_81;
    private String item_82;
    private String item_83;
    private String item_84;
    private String item_85;
    private String item_86;
    private String item_87;
    private String item_88;
    private String item_89;
    private String item_90;
    private String item_91;
    private String item_92;
    private String item_93;
    private String item_94;
    private String item_95;
    private String item_96;
    private String item_97;
    private String item_98;
    private String item_99;
    private String item_100;

    @Override
    public String toString() {
        return "Prj_Item_VO{" +
                "rn='" + rn + '\'' +
                ", route_num='" + route_num + '\'' +
                ", item_1='" + item_1 + '\'' +
                ", item_2='" + item_2 + '\'' +
                ", item_3='" + item_3 + '\'' +
                ", item_4='" + item_4 + '\'' +
                ", item_5='" + item_5 + '\'' +
                ", item_6='" + item_6 + '\'' +
                ", item_7='" + item_7 + '\'' +
                ", item_8='" + item_8 + '\'' +
                ", item_9='" + item_9 + '\'' +
                ", item_10='" + item_10 + '\'' +
                ", item_11='" + item_11 + '\'' +
                ", item_12='" + item_12 + '\'' +
                ", item_13='" + item_13 + '\'' +
                ", item_14='" + item_14 + '\'' +
                ", item_15='" + item_15 + '\'' +
                ", item_16='" + item_16 + '\'' +
                ", item_17='" + item_17 + '\'' +
                ", item_18='" + item_18 + '\'' +
                ", item_19='" + item_19 + '\'' +
                ", item_20='" + item_20 + '\'' +
                ", item_21='" + item_21 + '\'' +
                ", item_22='" + item_22 + '\'' +
                ", item_23='" + item_23 + '\'' +
                ", item_24='" + item_24 + '\'' +
                ", item_25='" + item_25 + '\'' +
                ", item_26='" + item_26 + '\'' +
                ", item_27='" + item_27 + '\'' +
                ", item_28='" + item_28 + '\'' +
                ", item_29='" + item_29 + '\'' +
                ", item_30='" + item_30 + '\'' +
                ", item_31='" + item_31 + '\'' +
                ", item_32='" + item_32 + '\'' +
                ", item_33='" + item_33 + '\'' +
                ", item_34='" + item_34 + '\'' +
                ", item_35='" + item_35 + '\'' +
                ", item_36='" + item_36 + '\'' +
                ", item_37='" + item_37 + '\'' +
                ", item_38='" + item_38 + '\'' +
                ", item_39='" + item_39 + '\'' +
                ", item_40='" + item_40 + '\'' +
                ", item_41='" + item_41 + '\'' +
                ", item_42='" + item_42 + '\'' +
                ", item_43='" + item_43 + '\'' +
                ", item_44='" + item_44 + '\'' +
                ", item_45='" + item_45 + '\'' +
                ", item_46='" + item_46 + '\'' +
                ", item_47='" + item_47 + '\'' +
                ", item_48='" + item_48 + '\'' +
                ", item_49='" + item_49 + '\'' +
                ", item_50='" + item_50 + '\'' +
                ", item_51='" + item_51 + '\'' +
                ", item_52='" + item_52 + '\'' +
                ", item_53='" + item_53 + '\'' +
                ", item_54='" + item_54 + '\'' +
                ", item_55='" + item_55 + '\'' +
                ", item_56='" + item_56 + '\'' +
                ", item_57='" + item_57 + '\'' +
                ", item_58='" + item_58 + '\'' +
                ", item_59='" + item_59 + '\'' +
                ", item_60='" + item_60 + '\'' +
                ", item_61='" + item_61 + '\'' +
                ", item_62='" + item_62 + '\'' +
                ", item_63='" + item_63 + '\'' +
                ", item_64='" + item_64 + '\'' +
                ", item_65='" + item_65 + '\'' +
                ", item_66='" + item_66 + '\'' +
                ", item_67='" + item_67 + '\'' +
                ", item_68='" + item_68 + '\'' +
                ", item_69='" + item_69 + '\'' +
                ", item_70='" + item_70 + '\'' +
                ", item_71='" + item_71 + '\'' +
                ", item_72='" + item_72 + '\'' +
                ", item_73='" + item_73 + '\'' +
                ", item_74='" + item_74 + '\'' +
                ", item_75='" + item_75 + '\'' +
                ", item_76='" + item_76 + '\'' +
                ", item_77='" + item_77 + '\'' +
                ", item_78='" + item_78 + '\'' +
                ", item_79='" + item_79 + '\'' +
                ", item_80='" + item_80 + '\'' +
                ", item_81='" + item_81 + '\'' +
                ", item_82='" + item_82 + '\'' +
                ", item_83='" + item_83 + '\'' +
                ", item_84='" + item_84 + '\'' +
                ", item_85='" + item_85 + '\'' +
                ", item_86='" + item_86 + '\'' +
                ", item_87='" + item_87 + '\'' +
                ", item_88='" + item_88 + '\'' +
                ", item_89='" + item_89 + '\'' +
                ", item_90='" + item_90 + '\'' +
                ", item_91='" + item_91 + '\'' +
                ", item_92='" + item_92 + '\'' +
                ", item_93='" + item_93 + '\'' +
                ", item_94='" + item_94 + '\'' +
                ", item_95='" + item_95 + '\'' +
                ", item_96='" + item_96 + '\'' +
                ", item_97='" + item_97 + '\'' +
                ", item_98='" + item_98 + '\'' +
                ", item_99='" + item_99 + '\'' +
                ", item_100='" + item_100 + '\'' +
                '}';
    }

    public String getRn() {
        return rn;
    }

    public void setRn(String rn) {
        this.rn = rn;
    }

    public String getRoute_num() {
        return route_num;
    }

    public void setRoute_num(String route_num) {
        this.route_num = route_num;
    }

    public String getItem_1() {
        return item_1;
    }

    public void setItem_1(String item_1) {
        this.item_1 = item_1;
    }

    public String getItem_2() {
        return item_2;
    }

    public void setItem_2(String item_2) {
        this.item_2 = item_2;
    }

    public String getItem_3() {
        return item_3;
    }

    public void setItem_3(String item_3) {
        this.item_3 = item_3;
    }

    public String getItem_4() {
        return item_4;
    }

    public void setItem_4(String item_4) {
        this.item_4 = item_4;
    }

    public String getItem_5() {
        return item_5;
    }

    public void setItem_5(String item_5) {
        this.item_5 = item_5;
    }

    public String getItem_6() {
        return item_6;
    }

    public void setItem_6(String item_6) {
        this.item_6 = item_6;
    }

    public String getItem_7() {
        return item_7;
    }

    public void setItem_7(String item_7) {
        this.item_7 = item_7;
    }

    public String getItem_8() {
        return item_8;
    }

    public void setItem_8(String item_8) {
        this.item_8 = item_8;
    }

    public String getItem_9() {
        return item_9;
    }

    public void setItem_9(String item_9) {
        this.item_9 = item_9;
    }

    public String getItem_10() {
        return item_10;
    }

    public void setItem_10(String item_10) {
        this.item_10 = item_10;
    }

    public String getItem_11() {
        return item_11;
    }

    public void setItem_11(String item_11) {
        this.item_11 = item_11;
    }

    public String getItem_12() {
        return item_12;
    }

    public void setItem_12(String item_12) {
        this.item_12 = item_12;
    }

    public String getItem_13() {
        return item_13;
    }

    public void setItem_13(String item_13) {
        this.item_13 = item_13;
    }

    public String getItem_14() {
        return item_14;
    }

    public void setItem_14(String item_14) {
        this.item_14 = item_14;
    }

    public String getItem_15() {
        return item_15;
    }

    public void setItem_15(String item_15) {
        this.item_15 = item_15;
    }

    public String getItem_16() {
        return item_16;
    }

    public void setItem_16(String item_16) {
        this.item_16 = item_16;
    }

    public String getItem_17() {
        return item_17;
    }

    public void setItem_17(String item_17) {
        this.item_17 = item_17;
    }

    public String getItem_18() {
        return item_18;
    }

    public void setItem_18(String item_18) {
        this.item_18 = item_18;
    }

    public String getItem_19() {
        return item_19;
    }

    public void setItem_19(String item_19) {
        this.item_19 = item_19;
    }

    public String getItem_20() {
        return item_20;
    }

    public void setItem_20(String item_20) {
        this.item_20 = item_20;
    }

    public String getItem_21() {
        return item_21;
    }

    public void setItem_21(String item_21) {
        this.item_21 = item_21;
    }

    public String getItem_22() {
        return item_22;
    }

    public void setItem_22(String item_22) {
        this.item_22 = item_22;
    }

    public String getItem_23() {
        return item_23;
    }

    public void setItem_23(String item_23) {
        this.item_23 = item_23;
    }

    public String getItem_24() {
        return item_24;
    }

    public void setItem_24(String item_24) {
        this.item_24 = item_24;
    }

    public String getItem_25() {
        return item_25;
    }

    public void setItem_25(String item_25) {
        this.item_25 = item_25;
    }

    public String getItem_26() {
        return item_26;
    }

    public void setItem_26(String item_26) {
        this.item_26 = item_26;
    }

    public String getItem_27() {
        return item_27;
    }

    public void setItem_27(String item_27) {
        this.item_27 = item_27;
    }

    public String getItem_28() {
        return item_28;
    }

    public void setItem_28(String item_28) {
        this.item_28 = item_28;
    }

    public String getItem_29() {
        return item_29;
    }

    public void setItem_29(String item_29) {
        this.item_29 = item_29;
    }

    public String getItem_30() {
        return item_30;
    }

    public void setItem_30(String item_30) {
        this.item_30 = item_30;
    }

    public String getItem_31() {
        return item_31;
    }

    public void setItem_31(String item_31) {
        this.item_31 = item_31;
    }

    public String getItem_32() {
        return item_32;
    }

    public void setItem_32(String item_32) {
        this.item_32 = item_32;
    }

    public String getItem_33() {
        return item_33;
    }

    public void setItem_33(String item_33) {
        this.item_33 = item_33;
    }

    public String getItem_34() {
        return item_34;
    }

    public void setItem_34(String item_34) {
        this.item_34 = item_34;
    }

    public String getItem_35() {
        return item_35;
    }

    public void setItem_35(String item_35) {
        this.item_35 = item_35;
    }

    public String getItem_36() {
        return item_36;
    }

    public void setItem_36(String item_36) {
        this.item_36 = item_36;
    }

    public String getItem_37() {
        return item_37;
    }

    public void setItem_37(String item_37) {
        this.item_37 = item_37;
    }

    public String getItem_38() {
        return item_38;
    }

    public void setItem_38(String item_38) {
        this.item_38 = item_38;
    }

    public String getItem_39() {
        return item_39;
    }

    public void setItem_39(String item_39) {
        this.item_39 = item_39;
    }

    public String getItem_40() {
        return item_40;
    }

    public void setItem_40(String item_40) {
        this.item_40 = item_40;
    }

    public String getItem_41() {
        return item_41;
    }

    public void setItem_41(String item_41) {
        this.item_41 = item_41;
    }

    public String getItem_42() {
        return item_42;
    }

    public void setItem_42(String item_42) {
        this.item_42 = item_42;
    }

    public String getItem_43() {
        return item_43;
    }

    public void setItem_43(String item_43) {
        this.item_43 = item_43;
    }

    public String getItem_44() {
        return item_44;
    }

    public void setItem_44(String item_44) {
        this.item_44 = item_44;
    }

    public String getItem_45() {
        return item_45;
    }

    public void setItem_45(String item_45) {
        this.item_45 = item_45;
    }

    public String getItem_46() {
        return item_46;
    }

    public void setItem_46(String item_46) {
        this.item_46 = item_46;
    }

    public String getItem_47() {
        return item_47;
    }

    public void setItem_47(String item_47) {
        this.item_47 = item_47;
    }

    public String getItem_48() {
        return item_48;
    }

    public void setItem_48(String item_48) {
        this.item_48 = item_48;
    }

    public String getItem_49() {
        return item_49;
    }

    public void setItem_49(String item_49) {
        this.item_49 = item_49;
    }

    public String getItem_50() {
        return item_50;
    }

    public void setItem_50(String item_50) {
        this.item_50 = item_50;
    }

    public String getItem_51() {
        return item_51;
    }

    public void setItem_51(String item_51) {
        this.item_51 = item_51;
    }

    public String getItem_52() {
        return item_52;
    }

    public void setItem_52(String item_52) {
        this.item_52 = item_52;
    }

    public String getItem_53() {
        return item_53;
    }

    public void setItem_53(String item_53) {
        this.item_53 = item_53;
    }

    public String getItem_54() {
        return item_54;
    }

    public void setItem_54(String item_54) {
        this.item_54 = item_54;
    }

    public String getItem_55() {
        return item_55;
    }

    public void setItem_55(String item_55) {
        this.item_55 = item_55;
    }

    public String getItem_56() {
        return item_56;
    }

    public void setItem_56(String item_56) {
        this.item_56 = item_56;
    }

    public String getItem_57() {
        return item_57;
    }

    public void setItem_57(String item_57) {
        this.item_57 = item_57;
    }

    public String getItem_58() {
        return item_58;
    }

    public void setItem_58(String item_58) {
        this.item_58 = item_58;
    }

    public String getItem_59() {
        return item_59;
    }

    public void setItem_59(String item_59) {
        this.item_59 = item_59;
    }

    public String getItem_60() {
        return item_60;
    }

    public void setItem_60(String item_60) {
        this.item_60 = item_60;
    }

    public String getItem_61() {
        return item_61;
    }

    public void setItem_61(String item_61) {
        this.item_61 = item_61;
    }

    public String getItem_62() {
        return item_62;
    }

    public void setItem_62(String item_62) {
        this.item_62 = item_62;
    }

    public String getItem_63() {
        return item_63;
    }

    public void setItem_63(String item_63) {
        this.item_63 = item_63;
    }

    public String getItem_64() {
        return item_64;
    }

    public void setItem_64(String item_64) {
        this.item_64 = item_64;
    }

    public String getItem_65() {
        return item_65;
    }

    public void setItem_65(String item_65) {
        this.item_65 = item_65;
    }

    public String getItem_66() {
        return item_66;
    }

    public void setItem_66(String item_66) {
        this.item_66 = item_66;
    }

    public String getItem_67() {
        return item_67;
    }

    public void setItem_67(String item_67) {
        this.item_67 = item_67;
    }

    public String getItem_68() {
        return item_68;
    }

    public void setItem_68(String item_68) {
        this.item_68 = item_68;
    }

    public String getItem_69() {
        return item_69;
    }

    public void setItem_69(String item_69) {
        this.item_69 = item_69;
    }

    public String getItem_70() {
        return item_70;
    }

    public void setItem_70(String item_70) {
        this.item_70 = item_70;
    }

    public String getItem_71() {
        return item_71;
    }

    public void setItem_71(String item_71) {
        this.item_71 = item_71;
    }

    public String getItem_72() {
        return item_72;
    }

    public void setItem_72(String item_72) {
        this.item_72 = item_72;
    }

    public String getItem_73() {
        return item_73;
    }

    public void setItem_73(String item_73) {
        this.item_73 = item_73;
    }

    public String getItem_74() {
        return item_74;
    }

    public void setItem_74(String item_74) {
        this.item_74 = item_74;
    }

    public String getItem_75() {
        return item_75;
    }

    public void setItem_75(String item_75) {
        this.item_75 = item_75;
    }

    public String getItem_76() {
        return item_76;
    }

    public void setItem_76(String item_76) {
        this.item_76 = item_76;
    }

    public String getItem_77() {
        return item_77;
    }

    public void setItem_77(String item_77) {
        this.item_77 = item_77;
    }

    public String getItem_78() {
        return item_78;
    }

    public void setItem_78(String item_78) {
        this.item_78 = item_78;
    }

    public String getItem_79() {
        return item_79;
    }

    public void setItem_79(String item_79) {
        this.item_79 = item_79;
    }

    public String getItem_80() {
        return item_80;
    }

    public void setItem_80(String item_80) {
        this.item_80 = item_80;
    }

    public String getItem_81() {
        return item_81;
    }

    public void setItem_81(String item_81) {
        this.item_81 = item_81;
    }

    public String getItem_82() {
        return item_82;
    }

    public void setItem_82(String item_82) {
        this.item_82 = item_82;
    }

    public String getItem_83() {
        return item_83;
    }

    public void setItem_83(String item_83) {
        this.item_83 = item_83;
    }

    public String getItem_84() {
        return item_84;
    }

    public void setItem_84(String item_84) {
        this.item_84 = item_84;
    }

    public String getItem_85() {
        return item_85;
    }

    public void setItem_85(String item_85) {
        this.item_85 = item_85;
    }

    public String getItem_86() {
        return item_86;
    }

    public void setItem_86(String item_86) {
        this.item_86 = item_86;
    }

    public String getItem_87() {
        return item_87;
    }

    public void setItem_87(String item_87) {
        this.item_87 = item_87;
    }

    public String getItem_88() {
        return item_88;
    }

    public void setItem_88(String item_88) {
        this.item_88 = item_88;
    }

    public String getItem_89() {
        return item_89;
    }

    public void setItem_89(String item_89) {
        this.item_89 = item_89;
    }

    public String getItem_90() {
        return item_90;
    }

    public void setItem_90(String item_90) {
        this.item_90 = item_90;
    }

    public String getItem_91() {
        return item_91;
    }

    public void setItem_91(String item_91) {
        this.item_91 = item_91;
    }

    public String getItem_92() {
        return item_92;
    }

    public void setItem_92(String item_92) {
        this.item_92 = item_92;
    }

    public String getItem_93() {
        return item_93;
    }

    public void setItem_93(String item_93) {
        this.item_93 = item_93;
    }

    public String getItem_94() {
        return item_94;
    }

    public void setItem_94(String item_94) {
        this.item_94 = item_94;
    }

    public String getItem_95() {
        return item_95;
    }

    public void setItem_95(String item_95) {
        this.item_95 = item_95;
    }

    public String getItem_96() {
        return item_96;
    }

    public void setItem_96(String item_96) {
        this.item_96 = item_96;
    }

    public String getItem_97() {
        return item_97;
    }

    public void setItem_97(String item_97) {
        this.item_97 = item_97;
    }

    public String getItem_98() {
        return item_98;
    }

    public void setItem_98(String item_98) {
        this.item_98 = item_98;
    }

    public String getItem_99() {
        return item_99;
    }

    public void setItem_99(String item_99) {
        this.item_99 = item_99;
    }

    public String getItem_100() {
        return item_100;
    }

    public void setItem_100(String item_100) {
        this.item_100 = item_100;
    }
}
