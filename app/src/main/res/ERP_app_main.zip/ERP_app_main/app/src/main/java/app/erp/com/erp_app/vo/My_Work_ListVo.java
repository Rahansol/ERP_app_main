package app.erp.com.erp_app.vo;

/**
 * Created by hsra on 2019-06-21.
 */

public class My_Work_ListVo {

    private String last_update;
    private String office_group;
    private String busoff_name;
    private String transp_bizr_id;
    private String bar_cnt;
    private String bus_bar_code;
    private String bus_num;
    private String rnum;

    private String unit_name;
    private String unit_bar_code;
    private String eb_serial;

    public String getLast_update() {
        return last_update;
    }

    public void setLast_update(String last_update) {
        this.last_update = last_update;
    }

    public String getOffice_group() {
        return office_group;
    }

    public void setOffice_group(String office_group) {
        this.office_group = office_group;
    }

    public String getBusoff_name() {
        return busoff_name;
    }

    public void setBusoff_name(String busoff_name) {
        this.busoff_name = busoff_name;
    }

    public String getTransp_bizr_id() {
        return transp_bizr_id;
    }

    public void setTransp_bizr_id(String transp_bizr_id) {
        this.transp_bizr_id = transp_bizr_id;
    }

    public String getBar_cnt() {
        return bar_cnt;
    }

    public void setBar_cnt(String bar_cnt) {
        this.bar_cnt = bar_cnt;
    }

    public String getBus_bar_code() {
        return bus_bar_code;
    }

    public void setBus_bar_code(String bus_bar_code) {
        this.bus_bar_code = bus_bar_code;
    }

    public String getBus_num() {
        return bus_num;
    }

    public void setBus_num(String bus_num) {
        this.bus_num = bus_num;
    }

    public String getRnum() {
        return rnum;
    }

    public void setRnum(String rnum) {
        this.rnum = rnum;
    }

    public String getEb_serial() {
        return eb_serial;
    }

    public void setEb_serial(String eb_serial) {
        this.eb_serial = eb_serial;
    }

    public String getUnit_name() {
        return unit_name;
    }

    public void setUnit_name(String unit_name) {
        this.unit_name = unit_name;
    }

    public String getUnit_bar_code() {
        return unit_bar_code;
    }

    public void setUnit_bar_code(String unit_bar_code) {
        this.unit_bar_code = unit_bar_code;
    }
}
