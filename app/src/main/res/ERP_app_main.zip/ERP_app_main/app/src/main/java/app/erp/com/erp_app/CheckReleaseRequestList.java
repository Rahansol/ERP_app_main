package app.erp.com.erp_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CheckReleaseRequestList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_release_request_list);
    }
}